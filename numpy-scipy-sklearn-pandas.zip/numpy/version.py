
# THIS FILE IS GENERATED FROM NUMPY SETUP.PY
#
# To compare versions robustly, use `numpy.lib.NumpyVersion`
short_version = '1.14.5'
version = '1.14.5'
full_version = '1.14.5'
git_revision = 'd3348c1123d3862a42d50a7fee14e50b268944a4'
release = True

if not release:
    version = full_version
