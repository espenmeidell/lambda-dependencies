********
backends
********

.. toctree::

   backend_bases_api.rst
   backend_managers_api.rst
   backend_mixed_api.rst
   backend_tools_api.rst
   backend_agg_api.rst
   backend_cairo_api.rst
   backend_gtkagg_api.rst
   backend_gtkcairo_api.rst
   backend_gtk3agg_api.rst
   backend_gtk3cairo_api.rst
   backend_nbagg_api.rst
   backend_pdf_api.rst
   backend_pgf_api.rst
   backend_ps_api.rst
   backend_qt4agg_api.rst
   backend_qt4cairo_api.rst
   backend_qt5agg_api.rst
   backend_qt5cairo_api.rst
   backend_svg_api.rst
   backend_tkagg_api.rst
   backend_webagg_api.rst
   backend_wxagg_api.rst
