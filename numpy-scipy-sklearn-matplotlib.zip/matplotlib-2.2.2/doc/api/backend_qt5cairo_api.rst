
:mod:`matplotlib.backends.backend_qt5cairo`
===========================================

.. automodule:: matplotlib.backends.backend_qt5cairo
   :members:
   :undoc-members:
   :show-inheritance:
