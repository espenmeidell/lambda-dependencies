*******
widgets
*******


:mod:`matplotlib.widgets`
=========================

.. automodule:: matplotlib.widgets
   :members:
   :undoc-members:
   :show-inheritance:
